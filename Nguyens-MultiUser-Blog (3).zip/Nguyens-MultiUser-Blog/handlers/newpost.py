import webapp2
from bloghandler import BlogHandler
from google.appengine.ext import db
from helpers import *
from models.post import Post
from models.user import User

# handler for posting a new story/blog
class NewPost(BlogHandler):
    '''constructor for this class.'''
    def get(self):
        if self.user:
            self.render("newpost.html")
        else:
            self.redirect("/login")

    def post(self):
        if not self.user:
            self.redirect('/blog')

        subject = self.request.get('subject')
        content = self.request.get('content')

        if subject and content:
            p = Post(parent=blog_key(),
                     subject=subject,
                     content=content,
                     created_by=User.by_name(self.user.name).name)

            p.put()
            self.redirect('/blog/%s' % str(p.key().id()))
        else:
            error = "subject and content, please!"
            self.render("newpost.html", subject=subject, content=content,
                        error=error)
